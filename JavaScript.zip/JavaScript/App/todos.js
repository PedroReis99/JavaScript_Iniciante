var listElement = document.querySelector('#app ul');
var inputElement = document.querySelector('#app input');
var buttonElement = document.querySelector('#app button');

//Itens basicos da lista
//var todos = [
//    'Fazer café',
//   'Estudar JavaScript',
//    'Acessar comunidade da rocketseat'
//];

//Variavel feita para carregar os itens salvos no armazenamento local da pagina web.
var todos = JSON.parse(localStorage.getItem('list_Todos')) || [];

function renderTodos(){
    listElement.innerHTML = '';

    for(todo of todos){
        //Lista todos os elementos
        var todoElement = document.createElement('li');
        var todoText = document.createTextNode(todo);

        //Método para excluir algum elemento
        var linkElement = document.createElement('a');
        linkElement.setAttribute('href','#');

        //Metodo para informar a posição do item na lista
        var posicao = todos.indexOf(todo);
        linkElement.setAttribute('onclick', 'deleteTodo('+ posicao +')');
        // -------------------------------------------------------------------
        var linkText = document.createTextNode('Excluir');

        linkElement.appendChild(linkText);

        //Lista os elementos
        todoElement.appendChild(todoText);
        //Adiciona o excluir nos elementos
        todoElement.appendChild(linkElement);
        listElement.appendChild(todoElement);
    }
}

renderTodos();

// função para adicionar itens a lista
function addTodo(){
    var todoText = inputElement.value;

    todos.push(todoText);
    inputElement.value = '';
    renderTodos();
    saveToSotorage();
}

buttonElement.onclick = addTodo;

// função para excluir itens da lista
function deleteTodo(posicao){
    todos.splice(posicao, 1);//O splice remove itens a partir de uma posição informada a ele. 
    renderTodos();
    saveToSotorage();
}

//Função para salvar informações de maneira local(Obs: mesmo se fechar a aplicação
//as informações vão continuar salvas)
function saveToSotorage(){
    localStorage.setItem('list_Todos', JSON.stringify(todos));
}


