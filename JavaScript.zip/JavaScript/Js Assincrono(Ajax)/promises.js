//outro método para realizar uma requisição externa no Ajax
var minhaPromise = function(){
    return new Promise(function(resolve, reject){
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://api.github.com/users/diego3g');
        xhr.send(null);

        xhr.onreadystatechange = function(){
            if(xhr.readyState === 4){
                if(xhr.status === 200){
                    resolve(JSON.parse(xhr.responseText));
                }else{
                    reject('Erro na requisição');
                    alert('Erro de requisição');
                }
            }
        }
    });
}

minhaPromise()
    .then(function(response){
        console.log(response);
    })// vai ser executado quando o resolve for chamado na promisse
    .catch(function(error){
        console.warn(error);
    });//vai ser executado quando ocorrer um erro de requisição da promisse
