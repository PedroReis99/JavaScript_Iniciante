//É uma requisição assincrona, ou seja, não acontece ao mesmo tempo que as requisições padrões da pagina
var xhr = new XMLHttpRequest(); //Nos da acesso as funcionalidades do ajax

//abrindo api do git-hub
xhr.open('GET', 'https://api.github.com/users/diego3g');
xhr.send(null);

xhr.onreadystatechange = function(){
    if(xhr.readyState === 4){
        console.log(JSON.parse(xhr.responseText));
    }
}